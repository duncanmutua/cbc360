document.addEventListener('DOMContentLoaded', function() {
    // Copy Till Number Functionality
    const copyBtn = document.querySelector('.btn-copy');
    if (copyBtn) {
        copyBtn.addEventListener('click', function() {
            const number = this.getAttribute('data-number');
            navigator.clipboard.writeText(number).then(() => {
                // Change button text temporarily
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="fas fa-check"></i> Copied!';
                
                // Show tooltip
                const tooltip = document.createElement('span');
                tooltip.className = 'tooltip';
                tooltip.textContent = 'Number copied to clipboard!';
                this.appendChild(tooltip);
                
                // Reset button after 2 seconds
                setTimeout(() => {
                    this.innerHTML = originalText;
                    tooltip.remove();
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        });
    }
    
    // Suggested Amount Buttons
    const amountBtns = document.querySelectorAll('.amount-btn');
    amountBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const amount = this.getAttribute('data-amount');
            
            // Highlight selected button
            amountBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // In a real implementation, this would initiate the payment process
            console.log(`Initiating donation of Ksh${amount} to +254757236138`);
            
            // Show success modal (simulating payment)
            setTimeout(() => {
                document.getElementById('donationModal').style.display = 'flex';
            }, 1500);
        });
    });
    
    // Modal Close Functionality
    const modal = document.getElementById('donationModal');
    const closeModal = document.querySelector('.close-modal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            modal.style.display = 'none';
        });
    }
    
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', function() {
            modal.style.display = 'none';
        });
    }
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
    
    // Simulate M-Pesa payment (for demo purposes)
    const donateBtn = document.querySelector('.btn-donate');
    if (donateBtn) {
        donateBtn.addEventListener('click', function(e) {
            if (window.location.pathname.includes('donate.html')) {
                e.preventDefault();
                document.getElementById('donationModal').style.display = 'flex';
            }
        });
    }
});